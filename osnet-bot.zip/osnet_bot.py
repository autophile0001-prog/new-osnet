from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import sqlite3, requests

# --- CONFIG ---
API_URL = "http://xploide.site/Api.php"
BOT_TOKEN = "YOUR_BOT_TOKEN"  # replace with your bot token
ADMIN_ID = 1218938666          # replace with your own Telegram ID

# --- DATABASE SETUP ---
conn = sqlite3.connect("credits.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT, credits INTEGER)")
conn.commit()

def get_credits(user_id):
    cursor.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    return row[0] if row else 0

def add_credits(user_id, username, amount):
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    row = cursor.fetchone()
    if not row:
        cursor.execute("INSERT INTO users (user_id, username, credits) VALUES (?, ?, ?)", (user_id, username, amount))
    else:
        cursor.execute("UPDATE users SET credits = credits + ?, username=? WHERE user_id=?", (amount, username, user_id))
    conn.commit()

def deduct_credit(user_id):
    cursor.execute("UPDATE users SET credits = credits - 1 WHERE user_id=? AND credits > 0", (user_id,))
    conn.commit()

# --- COMMANDS ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    username = update.message.from_user.username or "N/A"

    cursor.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
    row = cursor.fetchone()

    if not row:
        cursor.execute("INSERT INTO users (user_id, username, credits) VALUES (?, ?, ?)", (user_id, username, 0))
        conn.commit()
        credits = 0
    else:
        credits = row[0]

    await update.message.reply_text(
        f"👋 Welcome {update.message.from_user.first_name}!\n\n"
        f"🆔 Your Telegram ID: {user_id}\n"
        f"👤 Username: @{username}\n"
        f"💳 You have {credits} credits.\n\n"
        "➡️ Contact admin to get credits."
    )

async def mycredits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    credits = get_credits(user_id)
    await update.message.reply_text(f"💰 You have {credits} credits left.")

async def addcredits_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id != ADMIN_ID:
        await update.message.reply_text("❌ Only admin can add credits.")
        return

    try:
        target = context.args[0]
        amount = int(context.args[1])

        if target.isdigit():
            target_id = int(target)
            username = "N/A"
        else:
            cursor.execute("SELECT user_id, username FROM users WHERE username=?", (target,))
            row = cursor.fetchone()
            if not row:
                await update.message.reply_text("⚠️ User not found.")
                return
            target_id, username = row

        add_credits(target_id, username, amount)
        await update.message.reply_text(f"✅ Added {amount} credits to {target}")

    except Exception:
        await update.message.reply_text("⚠️ Usage: /addcredits <user_id|username> <amount>")

async def list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id != ADMIN_ID:
        await update.message.reply_text("❌ Only admin can view users.")
        return

    cursor.execute("SELECT user_id, username, credits FROM users")
    rows = cursor.fetchall()

    if not rows:
        await update.message.reply_text("⚠️ No users registered yet.")
        return

    reply = "👥 Registered Users & Credits:\n\n"
    for uid, uname, credits in rows:
        reply += f"🆔 {uid} (@{uname}) → 💳 {credits} credits\\n"

    await update.message.reply_text(reply)

# --- SEARCH HANDLER ---
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    username = update.message.from_user.username or "N/A"
    credits = get_credits(user_id)

    if credits <= 0:
        await update.message.reply_text("❌ You have no credits left. Contact admin.")
        return

    user_input = update.message.text.strip()
    if not user_input.isdigit():
        await update.message.reply_text("❌ Please enter digits only.")
        return

    try:
        response = requests.get(API_URL, params={"num": user_input})
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, list) and len(data) > 0:
                record = data[0]
                reply = (
                    f"📱 Mobile: {record.get('mobile', 'N/A')}\n"
                    f"👤 Name: {record.get('name', 'N/A')}\n"
                    f"👨‍👩 Father: {record.get('father_name', 'N/A')}\n"
                    f"🏠 Address: {record.get('address', 'N/A')}\n"
                    f"📞 Alt Mobile: {record.get('alt_mobile', 'N/A')}\n"
                    f"🌐 Circle: {record.get('circle', 'N/A')}\n"
                    f"🆔 ID Number: {record.get('id_number', 'N/A')}\n"
                    f"📧 Email: {record.get('email', 'N/A')}"
                )
                deduct_credit(user_id)
                left = get_credits(user_id)
                await update.message.reply_text(reply + f"\n\n💳 Credits left: {left}")
            else:
                await update.message.reply_text("⚠️ No records found.")
        else:
            await update.message.reply_text("❌ wait sometime or retry.")
    except Exception as e:
        await update.message.reply_text(f"⚠️ Exception: {e}")

# --- MAIN ---
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("mycredits", mycredits))
    app.add_handler(CommandHandler("addcredits", addcredits_cmd))
    app.add_handler(CommandHandler("users", list_users))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    print("🤖 Bot running with credit system...")
    app.run_polling()

if __name__ == "__main__":
    main()
